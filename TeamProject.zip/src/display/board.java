package display;

/**
 * Created by Admin on 4/19/2016.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class board extends JPanel implements ActionListener {
    Character p;                                                                                //Instance of player class
    Image background, menuBg;                                                                //The background images
    Timer time;                                                                              //A timer
    public menu Menu;

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    public static enum STATE {MENU, GAME}

    ;

    public static STATE State = STATE.MENU;

    public board() {
        this.addMouseListener(new mouseInput());
        //Start running player class
        Menu = new menu();

                                                                //Listen for keys
        setFocusable(true);                                                                                                                  //Allows movement
        ImageIcon i = new ImageIcon("resources/images.jpg");                  //Image for menu
        menuBg = i.getImage();
        i = new ImageIcon("resources/b.png");  //Image for background
        background = i.getImage();                                                           //Give the background the image
        time = new Timer(20, this);                                                           //Timer set to update "this" class every 20 milliseconds(Approximately 50fps)
        time.start();                                                                        //Actually start the timer
    }

}