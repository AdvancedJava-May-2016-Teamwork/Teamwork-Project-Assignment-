package game;

/**
 * Created by Admin on 6/5/2016.
 */
public class InputHandler {
}
