package game;

import com.company.Game;

public class Launcher {
    public static void main(String[] args) {
        Game game = new Game("Title game!", 400, 400);
        game.start();
    }
}
