package gameAssets;

import com.company.Game;

/**
 * Created by RoYaL on 11/6/2015.
 */
public class EmptyRes extends Res {


    public EmptyRes(Game game) {
        super();
    }

    @Override
    public String getType() {
        return "Empty Res";
    }

    @Override
    public boolean moveTo(Player from) throws Exception {
        return true;
    }


}
