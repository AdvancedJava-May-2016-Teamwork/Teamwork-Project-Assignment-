package gameAssets;

import com.company.Game;

/**
 * Created by RoYaL on 11/6/2015.
 */
public class PartsOfMap extends Res {

    private Player owner;

    public PartsOfMap(Game game, Player owner) {
        super();
        this.owner = owner;
    }

    @Override
    public String getType() {
        return "Area " + this.owner.getType();
    }

    @Override
    public boolean moveTo(Player from) throws Exception {
        return false;
    }
}
