package gameAssets;

import com.company.Game;

/**
 * Created by RoYaL on 11/6/2015.
 */
public class ResSource {

    public static Res create(char el, int row, int col, Game game) throws Exception {

        Res e;

        switch (el) {
            case 'a':
                e = game.getPlayerOne();
                break;
            case 'b':
                e = game.getPlayerTwo();
                break;
            case 'f':
                PartsOfMap area1 = new PartsOfMap(game, game.getPlayerOne());
                game.getPlayerOne().addPartsOfMap(area1);
                e = area1;
                break;
            case 'v':
                PartsOfMap area2 = new PartsOfMap(game, game.getPlayerTwo());
                game.getPlayerTwo().addPartsOfMap(area2);
                e = area2;
                break;
            case 'e':
                e = new EmptyRes(game);
                break;
            case 'o':
                e = new Obstacle(game);
                break;
            case 'g':
                e = new Gold(game, 1000 + ((int)(Math.random() * 4000)));
                break;
            default:
                throw new Exception("Invalid element name supplied");
        }

        e.setRow(row);
        e.setCol(col);

        return e;
    }

}
